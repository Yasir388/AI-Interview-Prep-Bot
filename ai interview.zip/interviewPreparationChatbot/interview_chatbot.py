from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import pymysql.cursors
from transformers import DistilBertTokenizer, DistilBertForSequenceClassification, pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import time

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# DB configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '1234',
    'database': 'interview_db',
    'cursorclass': pymysql.cursors.DictCursor
}

# Job roles list
job_labels = [
    'AI Research Scientist', 'Backend Developer', 'Blockchain Developer', 'Cloud Architect',
    'Computer Vision Engineer', 'Cybersecurity Analyst', 'Data Analyst', 'Data Engineer',
    'Data Scientist', 'Database Administrator', 'DevOps Engineer', 'Embedded Systems Engineer',
    'Frontend Developer', 'Full Stack Developer', 'Game Developer', 'Information Security Engineer',
    'Machine Learning Engineer', 'Mobile App Developer', 'Network Administrator', 'Network Engineer',
    'Quantum Computing Researcher', 'Robotics Engineer', 'Site Reliability Engineer',
    'Software Architect', 'Software Engineer', 'Systems Analyst', 'UI/UX Designer', 'Web Developer',
    'AR/VR Developer', 'Big Data Engineer', 'Business Intelligence Analyst', 'Cloud Security Engineer',
    'Data Privacy Officer', 'Deep Learning Engineer', 'Distributed Systems Engineer',
    'Firmware Engineer', 'Graphics Programmer', 'IoT Developer', 'IT Project Manager',
    'Natural Language Processing Engineer', 'Penetration Tester', 'QA Engineer',
    'Software Development Manager', 'Systems Administrator', 'Technical Writer',
    'Bioinformatics Specialist', 'Computational Biologist', 'Cryptography Expert',
    'Geographic Information Systems Analyst', 'High Performance Computing Engineer'
]

# Load DistilBERT model
try:
    tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')
    model = DistilBertForSequenceClassification.from_pretrained(
        'distilbert-base-uncased',
        num_labels=len(job_labels)
    )
    classifier = pipeline("text-classification", model=model, tokenizer=tokenizer)
except Exception as e:
    print(f"Error loading model: {e}")
    exit(1)

def classify_job_role(text):
    try:
        prediction = classifier(text)[0]
        label_index = int(prediction['label'].split('_')[1])
        return job_labels[label_index]
    except Exception as e:
        print(f"Error in classify_job_role: {e}")
        return None

def get_question_from_db(role):
    try:
        conn = pymysql.connect(**db_config)
        with conn.cursor() as cursor:
            sql = "SELECT id, question, keywords, correct_answer FROM questions WHERE role = %s ORDER BY RAND() LIMIT 1"
            cursor.execute(sql, (role,))
            question = cursor.fetchone()
        conn.close()
        if not question:
            print(f"No question found for role: {role}")
        return question
    except pymysql.MySQLError as err:
        print(f"MySQL Error: {err}")
        return None

def evaluate_answer(user_answer, correct_answer):
    try:
        docs = [user_answer, correct_answer]
        tfidf = TfidfVectorizer().fit_transform(docs)
        similarity = cosine_similarity(tfidf[0:1], tfidf[1:2])[0][0]
        score = min((similarity * 10) / 0.25, 10.0)
        return round(score, 2)
    except Exception as e:
        print(f"Error in evaluate_answer: {e}")
        return 0.0

def save_user_answer(question_id, user_answer, score, time_taken, user_name, user_email):
    try:
        conn = pymysql.connect(**db_config)
        with conn.cursor() as cursor:
            sql = "INSERT INTO user_answers (question_id, user_answer, score, time_taken, user_name, user_email) VALUES (%s, %s, %s, %s, %s, %s)"
            cursor.execute(sql, (question_id, user_answer, score, time_taken, user_name, user_email))
            conn.commit()
        conn.close()
    except pymysql.MySQLError as err:
        print(f"MySQL Error in save_user_answer: {err}")

def get_user_history():
    try:
        conn = pymysql.connect(**db_config)
        with conn.cursor() as cursor:
            sql = """
                SELECT user_name, user_email, SUM(score) as total_score
                FROM user_answers
                GROUP BY user_name, user_email
                ORDER BY total_score DESC
            """
            cursor.execute(sql)
            users = cursor.fetchall()
        conn.close()
        return users
    except pymysql.MySQLError as err:
        print(f"MySQL Error in get_user_history: {err}")
        return []

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        name = request.form.get("name")
        email = request.form.get("email")
        if name and email:
            session['user_name'] = name
            session['user_email'] = email
            return redirect(url_for("index"))
        return render_template("login.html", error="Please provide both name and email.")
    return render_template("login.html")

@app.route("/index")
def index():
    if 'user_name' not in session:
        return redirect(url_for("login"))
    user_history = get_user_history()
    return render_template("index.html", user_name=session['user_name'], user_history=user_history)

@app.route("/get_question", methods=["POST"])
def get_question():
    try:
        data = request.json
        selected_role = data.get("selected_role")
        user_input = data.get("input")

        if not selected_role and not user_input:
            return jsonify({"error": "No role or input provided"}), 400

        # Use selected_role if provided, otherwise classify user_input
        if selected_role:
            # Convert dropdown role to title case to match job_labels
            role = ' '.join(word.capitalize() for word in selected_role.split())
            if role not in job_labels:
                return jsonify({"error": f"Invalid role: {role}"}), 400
        else:
            role = classify_job_role(user_input)
            if not role:
                return jsonify({"error": "Could not classify role from input"}), 400

        question = get_question_from_db(role)
        if not question:
            return jsonify({"error": f"No question found for role: {role}"}), 404

        return jsonify({
            "role": role,
            "question": question["question"],
            "qid": question["id"],
            "start_time": int(time.time())
        })
    except Exception as e:
        print(f"Error in get_question: {e}")
        return jsonify({"error": "Internal server error"}), 500

@app.route("/submit_answer", methods=["POST"])
def submit_answer():
    try:
        user_answer = request.json.get("answer", "")
        qid = request.json.get("qid")
        start_time = request.json.get("start_time")
        end_time = int(time.time())
        time_taken = end_time - start_time

        if not qid:
            return jsonify({"error": "Question ID missing"}), 400

        conn = pymysql.connect(**db_config)
        with conn.cursor() as cursor:
            sql = "SELECT correct_answer FROM questions WHERE id = %s"
            cursor.execute(sql, (qid,))
            result = cursor.fetchone()
        conn.close()

        if not result:
            return jsonify({"error": "Question not found"}), 404

        score = evaluate_answer(user_answer, result["correct_answer"]) if user_answer else 0.0
        feedback = "Great answer!" if score >= 2.5 else "Try to cover more key points." if user_answer else "No answer submitted."

        save_user_answer(qid, user_answer, score, time_taken, session['user_name'], session['user_email'])

        return jsonify({
            "score": score,
            "feedback": feedback,
            "time_taken": time_taken
        })
    except pymysql.MySQLError as err:
        print(f"MySQL Error: {err}")
        return jsonify({"error": "Database error occurred"}), 500
    except Exception as e:
        print(f"Error in submit_answer: {e}")
        return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    app.run(debug=True , port=5001)